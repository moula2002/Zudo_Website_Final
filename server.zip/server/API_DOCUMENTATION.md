# Zudo API Documentation

**Base URL**: `https://lightgreen-trout-176417.hostingersite.com`

## 🔐 Authentication
Most POST, PUT, and DELETE routes require a Bearer Token.

### Admin Login
- **Endpoint**: `POST /api/auth/login`
- **Body**: `{ "email": "...", "password": "..." }`
- **Response**: Returns a `token` to be used in the header: `Authorization: Bearer <token>`

---

## 📦 Products

### Get All Products
- **Endpoint**: `GET /api/products`
- **Description**: Fetches all products with populated Category and SubCategory details.

### Create Single Product (with Image & PDF)
- **Endpoint**: `POST /api/products`
- **Auth**: Required
- **Type**: `multipart/form-data`
- **Fields**:
  - `name`: String
  - `categoryId`: MongoDB ObjectId
  - `subCategoryId`: MongoDB ObjectId (optional)
  - `price`: Number
  - `b2bPrice`: Number
  - `moq`: Number
  - `unit`: String (e.g., "1kg", "pcs")
  - `image`: File (JPEG/PNG/WEBP)
  - `pdf`: File (PDF)
- **Response**: The created product object.

### Bulk Upload via Excel
- **Endpoint**: `POST /api/products/bulk-upload`
- **Auth**: Required
- **Type**: `multipart/form-data`
- **Fields**:
  - `file`: Excel file (.xlsx)
- **Excel Format**: Should have columns: `Name`, `Category`, `SubCategory`, `Price`, `B2BPrice`, `MOQ`, `Unit`, `ImageUrl`, `Rating`.

---

## 📁 Categories & Sub-Categories

### Get All Categories
- **Endpoint**: `GET /api/categories`
- **Description**: Returns all categories with their nested sub-categories.

### Create Category
- **Endpoint**: `POST /api/categories`
- **Auth**: Required
- **Body**: `{ "name": "...", "imageUrl": "..." }`

### Create Sub-Category
- **Endpoint**: `POST /api/categories/sub`
- **Auth**: Required
- **Body**: `{ "name": "...", "imageUrl": "...", "categoryId": "..." }`

---

## 📁 Generic File Upload (Reviews & Verification)

### Upload Image or PDF
- **Endpoint**: `POST /api/upload`
- **Description**: Use this for uploading verification documents (PDF) or review images from the app/website.
- **Type**: `multipart/form-data`
- **Fields**:
  - `file`: The Image or PDF file.
- **Response**: 
  ```json
  {
    "message": "File uploaded successfully",
    "url": "/uploads/file-1714471234567.pdf",
    "filename": "file-1714471234567.pdf",
    "mimetype": "application/pdf"
  }
  ```

---

## 📂 Static Files & Media

All uploaded files (images and PDFs) are stored in the `/uploads` directory on the server.

### Viewing a file
- **URL Pattern**: `{BaseURL}/uploads/{filename}`
- **Example Image**: `https://lightgreen-trout-176417.hostingersite.com/uploads/image-1714471234567.jpg`
- **Example PDF**: `https://lightgreen-trout-176417.hostingersite.com/uploads/pdf-1714471234567.pdf`

---

## 🛠 Testing with cURL

### Uploading a Product with Image & PDF
```bash
curl -X POST https://lightgreen-trout-176417.hostingersite.com/api/products \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -F "name=Sona Masoori Rice" \
  -F "price=100" \
  -F "b2bPrice=80" \
  -F "unit=1kg" \
  -F "categoryId=65f..." \
  -F "image=@/path/to/rice.jpg" \
  -F "pdf=@/path/to/catalog.pdf"
```

### Bulk Uploading Excel
```bash
curl -X POST https://lightgreen-trout-176417.hostingersite.com/api/products/bulk-upload \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -F "file=@/path/to/products.xlsx"
```
